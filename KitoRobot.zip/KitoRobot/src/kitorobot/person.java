
package kitorobot;
import java.util.Scanner;

public class person {
    protected int personid;
    protected String PersonName ;
    protected void InputInfo(){
        
         Scanner input=new Scanner(System.in); 
         System.out.println("Enter person id ");
         personid=input.nextInt();
         System.out.println("Enter the person name");
         PersonName=input.nextLine();
         
     
         
         
    }
    
}
