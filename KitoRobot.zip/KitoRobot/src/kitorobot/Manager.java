
package kitorobot;

import java .util.Scanner;
public class Manager extends person {

protected int Robotid;
protected String status;

public void set_status(){
    
    
    
     Scanner input =new Scanner (System.in);   
     System.out.println("Enter the status");
     
     status=input.nextLine();
     
    
}

public void set_Robotid(int id ){
    Robotid=id;
    
}





    
}
