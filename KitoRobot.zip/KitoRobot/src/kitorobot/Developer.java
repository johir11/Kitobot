
package kitorobot;


public class Developer extends person {
    
    
    
    
    
}
