
package kitorobot;
import java .util.Scanner;

public class Robot {
    
    protected int Robotid;
    protected String RobotName;
    protected String RobotType;
    protected int Devid[];
    protected int id,i;
    
    public void all(){
Scanner input= new Scanner (System.in);     
        System.out.println("Enter robot id");
        Robotid= input.nextInt();
        System.out.println("Enter the robot name");
        RobotName=input.nextLine();
        System.out.println("Enter the robot type");
        RobotType=input.nextLine();
        
}
    public int get_Robotid(){
        return Robotid;
        
    }
    public void DevNoAssaignByManger(int noOfDev){
        
        Devid = new int [noOfDev];
        
        
    }
    
    public void set_Devid(int devid){
        
        Devid[i]=devid;
        i++;
    }
    public int get_id(){
        return id;
    }
    
}
